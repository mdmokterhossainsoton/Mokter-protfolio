import Image from 'next/image';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white text-gray-800 p-6">
      <div className="max-w-4xl mx-auto grid gap-8">

        {/* Header Section */}
        <header className="text-center mt-10">
          <Image
            src="/mokter.jpg"
            alt="Md. Mokter Hossain Soton"
            width={150}
            height={150}
            className="rounded-full mx-auto shadow-lg"
          />
          <h1 className="text-3xl font-bold mt-4">Md. Mokter Hossain Soton</h1>
          <p className="text-gray-600">Automation Engineer | Senior Officer, Walton Hi-Tech PLC</p>
        </header>

        {/* About Section */}
        <section id="about">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold mb-4">About Me</h2>
              <p>
                I am an enthusiastic Automation Engineer currently working at Walton Hi-Tech PLC in the Engineering Service Management (ESM) department. I specialize in machine making, PLC programming, logic design, and system architecture for automation.
              </p>
              <p className="mt-4">
                I completed my Diploma in Electronics Technology from Rangpur Polytechnic Institute and am now pursuing a B.Sc. in Electrical and Electronics Engineering at Uttara University. Previously, I worked at CP Bangladesh Ltd. and Texeurop BD, and trained 13+ batches in automation systems at Mother Trade Automation.
              </p>
            </CardContent>
          </Card>
        </section>

        {/* Contact Section */}
        <section id="contact" className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Contact</h2>
          <p>Email: mokterrpi2001@gmail.com</p>
          <p>Phone: 01610395370</p>
          <div className="mt-4 space-x-2">
            <a href="/chgpt.pdf" download>
              <Button className="mr-2">Download CV</Button>
            </a>
            <a
              href="https://linkedin.com/comm/mynetwork/discovery-see-all?usecase=PEOPLE_FOLLOWS&followMember=md-mokter-hossain-soton-b5b159240"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button variant="outline">LinkedIn</Button>
            </a>
          </div>
        </section>
      </div>
    </div>
  );
}
